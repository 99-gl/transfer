# ccopt saved state clock_trees.tcl.gz

create_ccopt_clock_tree -name core_clock -source clk_i -no_skew_group 
